import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BetalingTest {

    /*@Test
    void samletPris() {
        Bestilling b = new Bestilling();
        b.tilfoejPizzaTilBestilling(new Pizza()); // 57
        b.tilfoejPizzaTilBestilling(new Pizza());// 61
        b.tilfoejPizzaTilBestilling(new Pizza()); // 57


  assertEquals((57 + 61 + 57), Betaling.samletPris(b));


    }*/

    @Test
   public void statisticTest(){
        JDBC jdbc = new JDBC();

        int pizzaId = jdbc.statistic();
        System.out.println(pizzaId);


    }



}