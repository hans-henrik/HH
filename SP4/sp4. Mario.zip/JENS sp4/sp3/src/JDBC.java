import java.sql.*;
import java.util.ArrayList;

public class JDBC {

    String JDBCURL = "jdbc:mysql://localhost/pizzabar";
    String username = "root";
    String password = "Cph-hm163";
    Connection connection = null;
    PreparedStatement Ps = null;
    ResultSet resultSet = null;
    ArrayList<Bestilling> ordreliste = new ArrayList();


     /*  public void pizzaOrdre() {


        String query = "select sum from ordre1";

        try {

            Ps = DriverManager.getConnection(JDBCURL, username, password);

            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                //System.out.println("ordre" + resultSet.getString("sum"));
                int x = resultSet.getInt("sum");
                System.out.println(x);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }*/

    public void createConnection(){
    try {
        this.connection = DriverManager.getConnection(JDBCURL, username, password);
    } catch(SQLException e) {
        e.printStackTrace();
    }
}
    public void selectOrdre() {
        this.createConnection();
        try {
            Ps = connection.prepareStatement("select * from ordre1 where sum >? and kundeNavn=? ");
            Ps.setInt(1,200);
            Ps.setString(2,"Jesper4");
            resultSet = Ps.executeQuery();
            writeResult(resultSet);
        }catch (SQLException e){
            e.printStackTrace();
        }


    }


    public int saveOrdre(Bestilling bestilling) {
        int ordreId = 0;

        this.createConnection();
        try {


            Ps = connection.prepareStatement("insert into pizzabar.bestilling (BestillingsTid,AfhentningsTid, Kundenavn)  values (?,?,?)",Statement.RETURN_GENERATED_KEYS);
            Ps.setString(3, bestilling.getKundenavn());
            Ps.setString(1, bestilling.getBestillingsTidspunkt());
            Ps.setString(2, bestilling.getAfhentningsTidspunkt());

            Ps.executeUpdate();


            ResultSet rs = Ps.getGeneratedKeys();
            if (rs.next()){
                ordreId=rs.getInt(1);
            }

            System.out.println(ordreId+"From database");
        } catch (SQLException throwables) {  // Ved ikke hvorfor, men det fik ovenstående settere til, at virke. IDK. JCØ
            throwables.printStackTrace();  // Ved ikke hvorfor, men det fik ovenstående settere til, at virke. IDK. JCØ
        }
        return ordreId;
    }


    public void saveOrdreToDatabase(Bestilling bestilling) {
        createConnection();
        int ordreId = saveOrdre(bestilling);
        bestilling.setOrdreNummer(ordreId);
      savePizzas(bestilling);
    }

    public int statistic(){
        int pizzaId = 0;
        createConnection();
        try {


            Ps = connection.prepareStatement("select pizzaId, count(*) from bestillingsdetails group by pizzaId order by count(*) desc");




            resultSet  = Ps.executeQuery();
            if (resultSet.next()){
                pizzaId=resultSet.getInt(1);
            }

        } catch (SQLException throwables) {  // Ved ikke hvorfor, men det fik ovenstående settere til, at virke. IDK. JCØ
            throwables.printStackTrace();  // Ved ikke hvorfor, men det fik ovenstående settere til, at virke. IDK. JCØ
        }
        return pizzaId;

    }





    private void savePizzas(Bestilling bestilling) {


        this.createConnection();
        try {

for (Pizza pizza : bestilling.getOrdrer()) {
    Ps = connection.prepareStatement("insert into pizzabar.bestillingsdetails (bestillingsId, pizzaId)  values (?,?)");
    Ps.setInt(1, bestilling.getOrdreNummer());
    Ps.setInt(2, pizza.getNummer());
    Ps.executeUpdate();
}

        } catch (SQLException e) {
            e.printStackTrace();
        }
        }

    private void writeResult(ResultSet resultSet) throws SQLException
    {
        while(resultSet.next())
        {
            String ordreNummer=resultSet.getString("ordreNummer");
            String pizzaNummer=resultSet.getString("pizzaNummer");
            String pizzaNavn = resultSet.getString("pizzaNavn");
            String kundeNavn = resultSet.getString("kundeNavn");
            String bestillingsTid = resultSet.getString("bestillingsTid");
            String sum = resultSet.getString("sum");
            System.out.println("ordreNummer:" + ordreNummer+ "\t "+pizzaNummer+"\t\t"+pizzaNavn+ "\t\t"+kundeNavn+ "\t\t"+bestillingsTid+"\t\t"+sum);
            System.out.println("\t sum: \t"+sum);
        }
    }


    public void removeOrdre() {
        this.createConnection();
        try {
            Ps = connection.prepareStatement("delete from pizzabar.ordre1 where kundenavn=?");

            Ps.setString(1,"Jens");
            Ps.execute();
            //writeResult(resultSet);
        }catch (SQLException e){
            e.printStackTrace();
        }


       /* int ordreId = b.getOrdreNummer();
        if (b == null) {
            System.out.println("ordren findes ikke");

        } else {
            ordreliste.remove(b);

            System.out.println("Ordre Nr.: " + odreId + ", er fjernet fra ordrelisten.");
        }*/
    }
}

