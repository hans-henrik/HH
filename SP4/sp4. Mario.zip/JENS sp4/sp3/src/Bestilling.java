import java.sql.Array;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Bestilling {
    private int ordreNummer;
    private String kundenavn;
    private int sum;
    private String bestillingsTidspunkt;
    private String afhentningsTidspunkt;
    private LocalDateTime realDate;
    private String kommentarTilOrdre;
    private ArrayList<Pizza> pizzaOrdre;
    private final int count = 0;

    public Bestilling(int OrdreNummer, String Kundenavn, int sum, String KommentarTilOrdre) {
        this.ordreNummer = OrdreNummer;
        this.kundenavn = Kundenavn;
        this.sum = sum;
        this.realDate = LocalDateTime.now();
        this.bestillingsTidspunkt = tidspunktSomString(this.realDate);
        this.afhentningsTidspunkt = tidspunktSomString(realDate.plusMinutes(15L));
        this.kommentarTilOrdre = KommentarTilOrdre;
        pizzaOrdre = new ArrayList();
    }


    public void tilfoejPizzaTilBestilling(Pizza newpizza) {
        pizzaOrdre.add(newpizza);
        System.out.println("Pizza nr.: " + newpizza.getNummer() + ", er blevet tilføjet til din bestilling."+"\n");
    }

    public void fjernPizzaFraBestilling(Pizza newpizza) {
        pizzaOrdre.remove(newpizza);
        System.out.println("Pizza nr.: " + newpizza.getNummer() + ", er blevet fjernet fra din bestilling.");
    }

   public String tidspunktSomString(LocalDateTime date){
       DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
       String formattedDate = date.format(myFormatObj);
       return formattedDate;
   }


    public void setSum(int sum) {
        this.sum = sum;
    }

    public void setOrdreNummer(int ordreNummer) {
        this.ordreNummer = ordreNummer;
    }

    public int getOrdreNummer() { return ordreNummer; }

    public ArrayList<Pizza> getOrdrer() { return this.pizzaOrdre; }

    // JC har lavet følgende.

    public String getKundenavn() { return kundenavn; }

    public int getSum() { return sum; }

    public String getBestillingsTidspunkt() { return bestillingsTidspunkt; }

    public String getAfhentningsTidspunkt() { return afhentningsTidspunkt; }

    public LocalDateTime getRealDate() { return realDate; }

    public String getKommentarTilOrdre() { return kommentarTilOrdre; }

    public ArrayList<Pizza> getPizzaOrdre() { return this.pizzaOrdre; }

    public int getCount() { return count; }

    // JC har lavet ovenstående.

    @Override
    public String toString() {
        return "Bestilling:" + "\n"
                +"Ordre Nr.: " + this.ordreNummer + ".\n"
                +"Kundens navn: " + this.kundenavn + ".\n"
                +"Total pris: " + this.sum + ",- \n"
                +"Bestillings tidspunkt: " + this.bestillingsTidspunkt + ".\n"
                +"Afhentnings tidspunkt: " + this.afhentningsTidspunkt + ".\n"
                +"Kommentar til ordre: " + this.kommentarTilOrdre + ". \n"
                +"Bestilte pizzaer: "+ "\n" + this.pizzaOrdre + "\n";
    }



}