import java.util.Scanner;

public class Main {

    static PizzaBar pizzabar;
    static Scanner scan = new Scanner(System.in);
    static int count = 0;
   // static Bestilling nuværendeBestilling;
   static JDBC jdbc = new JDBC();

    public static void main(String[] args) {

       // JDBC jdbc = new JDBC();

        // jdbc.saveOrdre();
        // jdbc.selectOrdre();
      // jdbc.removeOrdre();
       // jdbc.saveOrdreToDatabase();
        pizzabar = new PizzaBar();
        pizzabar.bestillingListe = new Bestillingliste();
        VisKontrolpanel();
        tilfoejNyBestilling();

    }

    public static void VisKontrolpanel() {
        pizzabar.displayOptions();

        boolean finished = false;
        while (!finished) {

            String choice = scan.nextLine();

            switch (choice) {
                case "1": // Vis menukort
                    pizzabar.menukort.VisMenuKort();
                    break;
                case "2": // Ny bestillinger
                    System.out.println("Vælg hvilke pizza'er der skal bestilles" + "\n" + "Tast 20 for at slette en pizza fra bestillingen" + "\n" + "Tast 0 for at afslutte nuværende bestilling");
                    tilfoejNyBestilling();
                    break;
                case "3":

                    pizzabar.bestillingListe.visOrdreListe();

                    break;
                case "4":
                    fjernBestilling();
                    break;
                case "5": //
                    seOmsætning();
                    break;

                case "6":
                    System.out.println(jdbc.statistic()+ " Mest solgt pizza");

                    break;
                case "0":
                    finished = true;
                    break;
            }
        }
    }

    private static void seOmsætning() {
        Omsætning omsætning = new Omsætning();
        omsætning.Omsætning();
    }






    private static void fjernBestilling() {
        System.out.println("Indtast det BestillingsNummer som du vil fjernet fra BestillingsListen" + "\n" + "Tast 0 for at vende tilbage til hovedmenuen");
        boolean finished = false;
        while(!finished) {

            String choice = scan.nextLine();
            int input = -1;

            try {
                input = Integer.parseInt(choice);
            }
            catch (NumberFormatException e) {
                System.out.println(e);
                fjernBestilling();
            }

            if (input == 0) {
                finished = true;
            }
            else
            {

                Bestilling b = pizzabar.bestillingListe.findOrdreUdFraNummer(input);

                if ( b == null){
                    System.out.println("odre findes ikke33333333");
                }else{
                    pizzabar.bestillingListe.fjernOrdre(b);
                }
            }
            }
        VisKontrolpanel();
        }



    public static int ordreId(){
        count = count+1;
        return count;

    }

    private static void tilfoejNyBestilling() {
        Bestilling nuværendeBestilling = new Bestilling(ordreId(), "John", 100, "Gerne uden salt."); // Indtast ordrenr., kundenavn, samlet pris og tidspunkt.
        Menukort menukort = new Menukort("Pizza");

        boolean finished = false;
        while(!finished) {

           String choice = scan.nextLine();
           int input = -1;


           try {
               input = Integer.parseInt(choice);
           }
           catch (NumberFormatException e) {
               System.out.println(e);
               tilfoejNyBestilling();
           }

           if (input == 0) {
               jdbc.saveOrdreToDatabase(nuværendeBestilling);
               finished = true;
           } else if(input==20) {
               System.out.println("Indtast pizzanummer på den pizza som skal slettets fra Bestillingslisten "+"\n" + "Tast 0 for at vende tilbage til bestillingen");
               fjernPizzaFraBestilling(nuværendeBestilling);
            }
           else if(input>0 && input < 15 )
           {
               Pizza p = pizzabar.menukort.getPizzaList().get(input-1);
               nuværendeBestilling.tilfoejPizzaTilBestilling(p);

        }else{
               System.out.println("Forkert tast" );
           }
        }

        System.out.println(nuværendeBestilling.getOrdrer()+"\n");
      nuværendeBestilling.setSum( Betaling.samletPris(nuværendeBestilling));
        pizzabar.tilfoejBestilling(nuværendeBestilling);

        VisKontrolpanel();
    }

    private static void fjernPizzaFraBestilling(Bestilling b) {
        Menukort menukort = new Menukort("Pizza");

        boolean finished = false;
        while(!finished) {

            String choice = scan.nextLine();
            int input = -1;

            try {
                input = Integer.parseInt(choice);
            } catch (NumberFormatException e) {
                System.out.println(e);
                fjernPizzaFraBestilling(b);
            }

            if (input == 0) {
                finished = true;
            } else {
                Pizza p = pizzabar.menukort.getPizzaList().get(input - 1);
                b.fjernPizzaFraBestilling(p);

            }
        }
    }
}
