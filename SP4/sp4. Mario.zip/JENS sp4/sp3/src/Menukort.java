import java.util.ArrayList;

public class Menukort {
    private String pizzaName;
    private ArrayList<Pizza> pizzaList;

    public Menukort(String name){
        this.pizzaList = new ArrayList<>();
        this.pizzaName = name;

        tilfoejPizzaerTilMenukort();
    }

    public ArrayList<Pizza> getPizzaList() {
        return pizzaList;
    }

    public void VisMenuKort()
    {
        System.out.println(this);
        Main.VisKontrolpanel();
    }

    public void tilfoejPizzaerTilMenukort()
    {
        pizzaList.add( new Pizza(1, "Vesuvio", "Tomatsauce, ost, skinke og oregano", 57));
        pizzaList.add( new Pizza(2, "Amerikaner", "Tomatsauce, ost, oksefars og oregano", 53));
        pizzaList.add( new Pizza(3, "Caccaciatore", "Tomatsauce, ost, pepperoni og oregano", 57));
        pizzaList.add( new Pizza(4, "Carbona", "Tomatsauce, ost, kødsauce, spaghetti, cocktailpølser og oregano", 63));
        pizzaList.add( new Pizza(5, "Dennis", "Tomatsauce, ost, skinke, pepperoni, cocktailpølser og oregano", 65));
        pizzaList.add( new Pizza(6, "Bertil", "Tomatsauce, ost, bacon og oregano", 57));
        pizzaList.add( new Pizza(7, "Silvia" ,"Tomatsauce, ost, pepperoni, rød peber, løg, oliven og oregano", 61));
        pizzaList.add( new Pizza(8, "Victoria", "Tomatsauce, ost, skinke, ananas, løg, champignon og oregano", 61));
        pizzaList.add( new Pizza(9, "Toronfo" ,"Tomatsauce, ost, skinke, bacon, kebab, chili og oregano", 61));
        pizzaList.add( new Pizza(10, "Capricciosa" ,"Tomatsauce, ost, skinke, champignon og oregano", 61));
        pizzaList.add( new Pizza(11, "Hawai" ,"Tomatsauce, ost, skinke, ananas og oregano", 61));
        pizzaList.add( new Pizza(12, "Le Blissola" ,"Tomatsauce, ost, skinke, rejer og oregano", 61));
        pizzaList.add( new Pizza(13, "Venezia" ,"Tomatsauce, ost, skinke, bacon og oregano", 61));
        pizzaList.add( new Pizza(14, "Mafia" ,"Tomatsauce, ost, pepperoni, bacon, løg og oregano", 61));
    }

    @Override
    public String toString() {
        String pizzas = this.pizzaName + "\n";
        for (Pizza pizza : this.pizzaList) {
            pizzas = pizzas + pizza.toString() + "\n";
        }
        return pizzas;
    }
}