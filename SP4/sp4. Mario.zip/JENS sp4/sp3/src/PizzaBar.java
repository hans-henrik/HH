import java.util.ArrayList;

class PizzaBar {
    ArrayList<String> options = new ArrayList<>();

    Menukort menukort;
    Bestillingliste bestillingListe;


    public  PizzaBar(){
        menukort = new Menukort("Mario's menukort");

        addOptions();
    }

    public void displayOptions() {
        System.out.println(this.options.get(0));
        System.out.println(this.options.get(1));
        System.out.println(this.options.get(2));
        System.out.println(this.options.get(3));
        System.out.println(this.options.get(4));
        System.out.println(this.options.get(5));
        System.out.println(this.options.get(6));
    }

    private void addOptions() {
        this.options.add("1) Vis Mario's Menukort."  );
        this.options.add("2) Tilføj pizza til din bestilling." );
        this.options.add("3) Vis BestillingsListe") ;
        this.options.add("4) Fjern Bestilling fra BestillingsListe");
        this.options.add("5) Se omsætning");
        this.options.add("6) Se statistisk");
        this.options.add("0) Gå tilbage i menuen.");


    }

    public void tilfoejBestilling(Bestilling bestilling) {
        bestillingListe.tilføjBestilling(bestilling);
    }

}
