public class Pizza  {

    @Override
    public String toString() {
        return "Pizza: " +
                "Nummer: " + nummer + ".  |  " +
                "Name: " + name + ".  |  " +
                "Ingredienser: " + ingredienser + ".  |  " +
                "Pris:" + pris + "\n";
    }

    int nummer;
    String name;
    String ingredienser;
    int pris;

    public Pizza(int nummer, String name, String ingredienser, int pris) {
        this.nummer = nummer;
        this.name = name;
        this.ingredienser = ingredienser;
        this.pris = pris;
    }

    public int getNummer() {
        return nummer;
    }

    public int getPris() {
        return pris;
    }

    public String getName() { return name; }

    public String getIngredienser() { return ingredienser; }
}

