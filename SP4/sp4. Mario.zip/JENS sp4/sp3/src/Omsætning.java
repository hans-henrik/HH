public class Omsætning {

    Bestillingliste bestillingliste = Main.pizzabar.bestillingListe;

    public void Omsætning() {

        int totalOmsætning = 0;

        for(Bestilling bs : bestillingliste.ordreliste) {
            totalOmsætning += Betaling.samletPris(bs);
        }
        System.out.println("I dag har jeg omsat for " + totalOmsætning + "Kr");
    }
}