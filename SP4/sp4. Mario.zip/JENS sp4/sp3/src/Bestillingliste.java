import java.util.ArrayList;

public class Bestillingliste {

    ArrayList<Bestilling> ordreliste = new ArrayList();

    public void visOrdreListe() {
        System.out.println("Følgende ordrer er bestilt: \n");
        for (Bestilling b : ordreliste){
            System.out.println(b);
        }

    }

    public void tilføjBestilling(Bestilling b) {
        ordreliste.add(b);
        System.out.println("Ordre Nr.: " + b.getOrdreNummer() + ", er tilføjet til ordrelisten.");
    }

    public void fjernOrdre(Bestilling b) {
int odreId = b.getOrdreNummer();
        if( b == null) {
            System.out.println("odre findes ikke");

        }else{
            ordreliste.remove(b);

        System.out.println("Ordre Nr.: " + odreId + ", er fjernet fra ordrelisten.");}
    }

    public Bestilling findOrdreUdFraNummer(int n) {


        Bestilling tmpOrdre = null;
        for (Bestilling ordre : ordreliste) {
            if (n == ordre.getOrdreNummer()) {
                tmpOrdre = ordre;

                return tmpOrdre;
            } else {
                System.out.println();
            }
        }
        return tmpOrdre;
    }

    @Override
    public String toString() {
        return "Ordreliste{" +
                "Ordreliste: " + ordreliste +
                '}';
    }
}