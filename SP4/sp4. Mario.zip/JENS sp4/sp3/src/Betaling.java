class Betaling {

    public static int samletPris(Bestilling bestilling) {
        int pris = 0;
        for (Pizza pizza : bestilling.getOrdrer()) {
            pris += pizza.getPris();
        }
        return pris;
    }

}
